using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Auto_Sculpt.Pages
{
    public class AdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
