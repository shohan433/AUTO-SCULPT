using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Auto_Sculpt.Pages
{
    public class BuyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
